# Global Solution – MLAM | CitizenTech

## Tema
Mobilidade urbana: análise da demanda por bicicletas compartilhadas em Seul (Coreia do Sul).

## Problema e objetivo
A disponibilidade de bicicletas compartilhadas precisa acompanhar a demanda horária. O projeto investiga como horário e condições meteorológicas se relacionam com o volume de aluguéis e com o funcionamento do serviço, produzindo análises que podem apoiar o planejamento operacional.

## Base de dados e fonte
- **Nome:** Seoul Bike Sharing Demand
- **Instituição:** UCI Machine Learning Repository
- **Período:** 2017–2018
- **Observações informadas pela UCI:** 8.760
- **Fonte original:** https://archive.ics.uci.edu/dataset/560/seoul+bike+sharing+demand
- **DOI:** https://doi.org/10.24432/C5F62R
- **Licença:** Creative Commons Attribution 4.0 (CC BY 4.0)

A base contém quantidade de bicicletas alugadas por hora, horário, temperatura, umidade, velocidade do vento, visibilidade, precipitação, neve, estação do ano, feriado e indicador de funcionamento do serviço.

## Métodos
1. Distribuição normal: probabilidades abaixo da média e acima da mediana para temperatura.
2. Testes Z unilaterais para média, com n=20 e α=6% (cauda esquerda) e n=25 e α=9% (cauda direita).
3. Análise bivariada: temperatura × aluguéis, covariância, Pearson, regressão simples, R², teste F e previsão.
4. Regressão linear múltipla: aluguéis como resposta e temperatura, umidade, vento e hora como explicativas.
5. Regressão logística: indicador original de funcionamento do serviço como resposta binária, com variáveis meteorológicas quantitativas.

## Limitações
Os dados descrevem Seul em 2017–2018 e não representam automaticamente outras cidades. A normalidade é assumida para cumprir o enunciado. Regressões lineares podem não representar relações não lineares e padrões sazonais. A classificação logística deve ser interpretada em conjunto com a matriz de confusão, pois as classes são desbalanceadas. Os resultados são associações, não provas de causalidade.
